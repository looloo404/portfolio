from django.urls import path
from . import views

urlpatterns = [
    path('', views.lecture_list, name ='lecture_list'),
    path('check_user_info/', views.check_user_info, name='check_user_info'),
    path('get_lecture_name/', views.get_lecture_name, name='get_lecture_name'),
]