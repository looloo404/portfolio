import json
from django.http import JsonResponse
from django.shortcuts import render
from .models import UserInfo, LectureInfo, ResultInfo, TutorInfo, EventInfo

def lecture_list(request):
    return render(request, 'EO_001.html')

def lecture_play(request):
    return render(request, 'EO_002.html')


def check_user_info(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        user_id = data.get('userId')
        password = data.get('password')

        # UserInfo 모델에서 사용자 정보와 일치하는지 확인
        try:
            user = UserInfo.objects.get(user=user_id, password=password)
            valid = True
        except UserInfo.DoesNotExist:
            valid = False

        response_data = {'valid': valid}
    return JsonResponse(response_data)


def get_lecture_name(request):
    lectures = LectureInfo.objects.all()
    tutors = TutorInfo.objects.all()
    return render(request, 'EO_001.html', {'lectures' : lectures, 'tutors': tutors})